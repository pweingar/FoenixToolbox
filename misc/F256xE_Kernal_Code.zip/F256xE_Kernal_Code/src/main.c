/* Read a text file and display it */
#include <stdio.h>
#include "ff15/ff.h"
#include "Network/Ethernet/wizchip_conf.h"
#include "Network/Ethernet/socket.h"     // THis is essentially all the call necessary to get some packets in and out
#include "Network/Internet/DNS/dns.h"
#include "Network/Internet/httpClient/httpClient.h"

#define SCREEN  (*(volatile __far uint8_t *)0xF04000)
/* ETH */
#define ETH_MAX_BUF_SIZE		2048
// WizNet (Copper) Module Access
#define WizNetCtrlReg       (*(volatile __far uint8_t *) 0xF018C0 ) // $F018C0 - RW - Control Register
#define WizNet_MR_Reg       (*(volatile __far uint8_t *) 0xF018C1 ) // $F018C1 - Read - MR Value  // Write - MR Value
#define WizNet_TX_FIFOCount (*(volatile __far uint8_t *) 0xF018C2 ) // $F018C2 - Read - TxFIFOCpunt[7:0] 
#define WizNetDataReg       (*(volatile __far uint8_t *) 0xF018C3 ) // $F018C3 - Read - Single Access Port / Write - Single Access Port 
#define WizNetAddyLoReg     (*(volatile __far uint8_t *) 0xF018C4 ) // $F018C4 - Read - WizNet Address Lo  / Write - WizNet Address Lo
#define WizNetAddyHiReg     (*(volatile __far uint8_t *) 0xF018C5 ) // $F018C5 - Read - WizNet Address Hi  / Write - WizNet Address Hi
#define WizNetSizeLoReg     (*(volatile __far uint8_t *) 0xF018C6 ) // $F018C6 - Read - Rx FIFO Quanity Lo / Write - WizNet Transfer Size Lo
#define WizNetSizeHiReg     (*(volatile __far uint8_t *) 0xF018C7 ) // $F018C7 - Read - Rx FIFO Quanity Hi / Write - WizNet Transfer Size Hi
// Read/Write FIFO Port for transfer > 1 Bytes
#define WizNetFIFO_Port     (*(volatile __far uint8_t *) 0xF018C8 ) // $F018C8 - Read - FIFO Port // Write - FIFO Port
// Control
// Bit [3:1] 
// 000: Write Single Transfer
// 001: Write Burst Transfer
// 010: Write MR Register 
// 011: Reserved
// 100: Read Single Transfer
// 101: Read Burst Transfer
// 110: Read MR Register 
// 111: Reserved

// [0] - Enable - 0: Block is disabled - 1: Block is Enabled
// [1] - See Above for value
// [2] - See Above for value 
// [3] - See Above for value 
// [4] - Reset FIFOs
// [5] - Start Transfer 
// [6] - Enable FIFO Empty/FIFO Full Interrupt
// [7] - Transfer in Progress

// Prototypes
void wizchip_initialize( void );
void wizchip_check(void);
void wizchip_dhcp_init(void);
void wizchip_reset( void );


FATFS SD0_FatFs;   /* Work area (filesystem object) for logical drive */
FATFS SD1_FatFs;   /* Work area (filesystem object) for logical drive */
FRESULT list_dir (const char *path);

/* NET */
/*
wiz_NetInfo gWIZNETINFO = {
		.mac = {0x00, 0x08, 0xdc, 0x6f, 0x00, 0x8a},
		.ip = {192, 168, 1, 99},
		.sn = {255, 255, 255, 0},
		.gw = {192, 168, 1, 254},
//		.dns = {208, 67, 222, 222},
        .dns = {192, 168, 1, 70},
		.dhcp = NETINFO_STATIC
};
*/
// Network Information
uint8_t mac_addr[6] = {0x00, 0x08, 0xDC, 0x71, 0x12, 0xAA}; 
uint8_t src_addr[4] = {192, 168, 1, 99};
uint8_t gw_addr[4]  = {192, 168, 1, 254};
uint8_t sub_addr[4] = {255, 255, 255,  0};

#define DATA_BUF_SIZE   2048
//uint8_t gDATABUF[DATA_BUF_SIZE];
//uint8_t ethBuf[ETH_MAX_BUF_SIZE];
//////////////////////////////////////////////////
// Socket & Port number definition for Examples //
//////////////////////////////////////////////////
#define SOCK_HTTPC      0
////////////////
// DNS client //
////////////////

//uint8_t Domain_name[] = "wiki.f256foenix.com";    	// for Example domain name
//uint8_t Domain_IP[4]  = {172,232,162,252 };             // Translated IP address by DNS Server
//uint8_t DNS_2nd[4]    = {8, 8, 8, 8};      	            // Secondary DNS server IP

// Shared buffer declaration
uint8_t g_send_buf[DATA_BUF_SIZE];
uint8_t g_recv_buf[DATA_BUF_SIZE];

// THis seems to work
//uint8_t Domain_name[] = "wiki.f256foenix.com";
//uint8_t Domain_IP[4]  = { 172,232,162,252 };                  //172.232.162.252 Translated IP address by DNS Server
//uint8_t URI[] = "/index.php?title=Main_Page";

//uint8_t Domain_name[] = "wiki.f256foenix.com";
uint8_t Domain_name[]  =  "foenixnet.com\0     ";
uint8_t Domain_IP[4]  = { 172,232,5,120 };     
//uint8_t URI[] = "/index.html\0              ";
uint8_t URI[] = "/files/f816.pgz\0          ";
//uint8_t URI[] = "/files\0                   ";
uint8_t flag_sent_http_request = 0;

// www.c256foenix.com - 69.164.201.182 (IPV4) - 2600:3c00::f03c:92ff:fe72:27d5 (IPV6)
// songseed.org (Port 2327) - 5.28.62.48 (IPV4)
// www.tim.org (/f256/) - 198.54.114.246 (IPV4)

//    char domain[] = "www.c256foenix.com";
//    char path[]="f256/pgztest.pgz";


int main (void)
{
    FIL fil;        /* File object */
    char str[12];    
    //char line[100]; /* Line buffer */
    FRESULT fr_SD0, fr_SD1, fr;     /* FatFs return code */
    uint8_t Status_Socket;    
	uint8_t tmp[6];    
	uint16_t len = 0, i = 0;

    printf("Booting from SD1:... \r");
    //WIZCHIP_WRITE(0x0000, 0x83 );
    /* Give a work area to the default drive */
      //fr_SD0 = f_mount(&SD0_FatFs, "0:", 1);  // External SDCard
      //printf("SD0 f_mount: %d\r", (int)fr_SD0 );
      fr_SD1 = f_mount(&SD1_FatFs, "1:", 1);  //Internal SDCard
      printf("SD1 f_mount: %d\r", (int)fr_SD1 );
    
     fr = f_getlabel("1:", str, 0);
     printf("Get Label Status: %d\r", (int) fr );
     printf("%s\r", str);
    
    fr = list_dir("1:/");
    printf("Get Directory Status: %d\r", (int) fr );
    //WIZCHIP_WRITE(0x0000, 0x03 );


	// Set default static IP settings
    setSHAR( mac_addr );
	setSIPR( src_addr );
	setGAR( gw_addr );
	setSUBR( sub_addr );

	/* Network Configuration (Default setting) */
	//printf("====== W%d NET CONF ======\r\n",_WIZCHIP_);
	//getSHAR(tmp); printf("MAC ADDRESS : %.2X:%.2X:%.2X:%.2X:%.2X:%.2X\r",tmp[0],tmp[1],tmp[2],tmp[3],tmp[4],tmp[5]); 
	//getSIPR(tmp); printf("IP ADDRESS : %.3d.%.3d.%.3d.%.3d\r",tmp[0],tmp[1],tmp[2],tmp[3]); 
	//getGAR(tmp);  printf("GW ADDRESS : %.3d.%.3d.%.3d.%.3d\r",tmp[0],tmp[1],tmp[2],tmp[3]); 
    //getSUBR(tmp); printf("SN MASK: %.3d.%.3d.%.3d.%.3d\r",tmp[0],tmp[1],tmp[2],tmp[3]);

	Status_Socket = httpc_init(SOCK_HTTPC, Domain_IP, 80, g_send_buf, g_recv_buf);
    printf("HTTP_Init Return Status: %x\r", Status_Socket);


while(1)
	{
		////////////////////////////////////////////
		// HTTP socket process handler
		////////////////////////////////////////////
		httpc_connection_handler();
		
		if(httpc_isSockOpen)
		{
			httpc_connect();
		}
		
		// HTTP client example	
		if(httpc_isConnected) 
		{
			if(!flag_sent_http_request)
			{
				// Send: HTTP request
				request.method = (uint8_t *)HTTP_GET;
				request.uri = (uint8_t *)URI;
				request.host = (uint8_t *)Domain_name;
				
				// HTTP client example #1: Function for send HTTP request (header and body fields are integrated)
				{
					httpc_send(&request, g_recv_buf, g_send_buf, 0);
				}
				
				// HTTP client example #2: Separate functions for HTTP request - default header + body
				{
					//httpc_send_header(&request, g_recv_buf, NULL, len);
					//httpc_send_body(g_send_buf, len); // Send HTTP requset message body
				}
				
				// HTTP client example #3: Separate functions for HTTP request with custom header fields - default header + custom header + body
				{
					//httpc_add_customHeader_field(tmpbuf, "Custom-Auth", "auth_method_string"); // custom header field extended - example #1
					//httpc_add_customHeader_field(tmpbuf, "Key", "auth_key_string"); // custom header field extended - example #2
					//httpc_send_header(&request, g_recv_buf, tmpbuf, len);
					//httpc_send_body(g_send_buf, len);
				}
				
				flag_sent_http_request = 1;
			}
			
			// Recv: HTTP response
			if(httpc_isReceived > 0)
			{
				len = httpc_recv(g_recv_buf, httpc_isReceived);
				
				printf(" >> HTTP Response - Received len: %d\r\n", len);
				printf("======================================================\r\n");
				for(i = 0; i < len; i++) printf("%c", g_recv_buf[i]);
				printf("\r\n");
				printf("======================================================\r\n");
			}
		}
	}



/*
  // For later: echo server "nc -vv songseed.org 2327"

//      fr = f_open(&fil, "1:/F256XE~1.txt", FA_READ);
//      printf("f_open: %d", (int)fr );
//      if (fr) return 
//         (int)fr;

//    while (f_gets(line, sizeof line, &fil)) {
//        printf("%s", line);
//    }
    //wizchip_init(bufSize[0], bufSize[1]);
    wizchip_setnetinfo(&gWIZNETINFO);

    wizchip_initialize();
  
	//printf("\r\n===== DNS Servers =====\r\n");
	//printf("> DNS 1st : %d.%d.%d.%d\r", gWIZNETINFO.dns[0], gWIZNETINFO.dns[1], gWIZNETINFO.dns[2], gWIZNETINFO.dns[3]);
	//printf("> DNS 2nd : %d.%d.%d.%d\r", DNS_2nd[0], DNS_2nd[1], DNS_2nd[2], DNS_2nd[3]);
	//printf("=======================================\r");
	//printf("> [Example] Target Domain Name : %s\r", Domain_name);  
   
    Status_Socket = socket(3, Sn_MR_TCP, 0, 0);    // Let's it assign a source port on its own.
    printf(">> Socket request response: %x \r", Status_Socket);
    
    Status_Socket = connect ( 3, Local_IP, 80);		// Socket number , DNS IP, DNS Port Number (53)    
	
    printf(">> Connect request response: %x \r", Status_Socket); 
	if (Status_Socket == 1) {
		printf("> Success to Connect...\r");
	}
	else {
		printf("> Failed to Connect...\r");
		close(3);		
	}
*/


/*
    DNS_init(SOCK_DNS, gDATABUF);
    if ((ret = DNS_run(gWIZNETINFO.dns, Domain_name, Domain_IP)) > 0) {
        printf("> 1st DNS Respond\r\n"); 
    }
    else {
        printf("> 1st DNS didn't Respond: %ld\r",ret );         
        if ((ret != -1) && ((ret = DNS_run(DNS_2nd, Domain_name, Domain_IP))>0)) {    // retry to 2nd DNS
            printf("> 2nd DNS Respond\r\n");
        }
        else {
            if(ret == -1) {
                printf("> MAX_DOMAIN_NAME is too small. Should be redefined it.\r\n");
                }
            else {
                 printf("> DNS Failed\r\n");
            }
        }
    }
*/

    // Let's try to get a file
    // Whatever I do next, I will need this: "http://www.tim.org" "/f256/pgztest.pgz"
//    Status_Socket = socket  ( 0, Sn_MR_TCP, source_port, Sn_MR_ND
  //uint8_t  protocol,  
  //uint16_t  port,  
  //uint8_t  flag  

    /* Close the file */
    f_close(&fil);

// WizNet Stuff

    while(1);
}

FRESULT list_dir (const char *path)
{
    FRESULT res;
    DIR dir;
    FILINFO fno;
    int nfile, ndir;

    res = f_opendir(&dir, path);                       /* Open the directory */
    if (res == FR_OK) {
        nfile = ndir = 0;
        for (;;) {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Error or end of dir */
            if (fno.fattrib & AM_DIR) {            /* Directory */
                printf("   <DIR>   %s\r", fno.fname);
                ndir++;
            } else {                               /* File */
                printf("%10lu %s\r", fno.fsize, fno.fname);
                nfile++;
            }
        }
        f_closedir(&dir);
        printf("%d dirs, %d files.\r", ndir, nfile);
    } else {
        printf("Failed to open \"%s\". (%u)\r", path, res);
    }
    return res;
}

/***************************************/
/******* NETWORK STUFF******************/
void wizchip_check(void) { 
    printf(" Chip Version: 0x%02x\n", getVER());
}


void wizchip_initialize(void)
{
	uint8_t W5100S_AdrSet[2][4]= {{2,2,2,2},{2,2,2,2}};
    uint8_t tmp1, tmp2;
	intr_kind temp= IK_DEST_UNREACH;
    printf(">>>>wizchip_initialize\r\n");
	wizchip_check();

	if (ctlwizchip(CW_INIT_WIZCHIP, (void*)W5100S_AdrSet) == -1)
		printf(">>>>W5100s memory initialization failed\r\n");
    else 
		printf(">>>>W5100s memory initialization succeed\r\n");    

	//if(ctlwizchip(CW_SET_INTRMASK,&temp) == -1)
	//	printf("W5100S interrupt\r\n");


	while(1)
	{
		ctlwizchip(CW_GET_PHYLINK, &tmp1 );
		ctlwizchip(CW_GET_PHYLINK, &tmp2 );
		if(tmp1==PHY_LINK_ON && tmp2==PHY_LINK_ON) 
            break;
	}
    printf("THe Link is up (0x003C) Value: 0x%04x\r", WIZCHIP_READ(0x003C));    
}
/*
void wizchip_dhcp_init(void)
{
    DHCP_init(SOCKET_DHCP, ethBuf);
    reg_dhcp_cbfunc(wizchip_dhcp_assign, wizchip_dhcp_assign, wizchip_dhcp_conflict);
}
*/
/* CHIP INIT */
void wizchip_reset( void )
{
	//HAL_GPIO_WritePin(RESET_W5100S_GPIO_Port, RESET_W5100S_Pin, GPIO_PIN_RESET);
	//HAL_Delay(10);
	//HAL_GPIO_WritePin(RESET_W5100S_GPIO_Port, RESET_W5100S_Pin, GPIO_PIN_SET);
	//HAL_Delay(100);
}