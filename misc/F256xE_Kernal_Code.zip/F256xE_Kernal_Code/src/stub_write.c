#include <errno.h>
#include <stubs.h>
#include <stdio.h>

extern void __kernel_putchar(char);

//#define CHROUT(c) __IPUTC(c)
#define CHROUT(c) ( (void (*)(char) ) __kernel_putchar) (c)
// Can call kernel directly in large code model only.
size_t _Stub_write (int fd, const void *buf, size_t count) {
  const char *p = buf;
  size_t n = 0;

  switch (fd) {
  case 1: {
    char c;
    while (count) {
      CHROUT(*p);
      n += 1;
      p += 1;
      count -= 1;
    }
    break;
    }
  default:
    __set_errno(EBADF);
    return (size_t) -1;
  }
  return n;
}

long _Stub_lseek (int fd, long offset, int whence) {
  return -1;
}

int _Stub_close (int fd) {
  return 0;
}